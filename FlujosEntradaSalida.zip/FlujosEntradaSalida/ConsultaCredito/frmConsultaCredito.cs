﻿using BibliotecaBanco;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsultaCredito
{
    public partial class frmConsultaCredito : Form
    {
        private FileStream entrada; // mantiene la conexión con el archivo
        private StreamReader archivoReader; // lee datos del archivo de texto

        // nombre del archivo que almacena los saldos con crédito, débito o en cero
        private String nombreArchivo;

        public frmConsultaCredito()
        {
            InitializeComponent();
        }

        private void btnAbrir_Click(object sender, EventArgs e)
        {
            OpenFileDialog selectorArchivo = new OpenFileDialog();
            DialogResult resultado = selectorArchivo.ShowDialog();

            if (resultado == DialogResult.Cancel)
                return;

            nombreArchivo = selectorArchivo.FileName; // obtiene el nombre de archivo del usuario

            if(nombreArchivo == "" || nombreArchivo == null)
                MessageBox.Show("Nombre de archivo inválido", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                entrada = new FileStream(nombreArchivo, FileMode.Open,
                    FileAccess.Read);
                archivoReader = new StreamReader(entrada);

                btnAbrir.Enabled = false;
                btnCredito.Enabled = true;
                btnDebito.Enabled = true;
                btnCero.Enabled = true;
            }
        }

        // se invoca cuando el usuario hace clic en el botón saldos con crédito,
        // saldos con débito o saldos en cero
        private void obtenerSaldos_Click(object sender, EventArgs e)
        {
            //convierte el emisor explicitamente a un objeto de tipo button
            Button enmisorButton = (Button)sender;

            // obtiene el texto del boton en el que se hizo click y almacena el tipo de la cuenta
            String tipoCuenta = enmisorButton.Text;

            try
            {
                //lee y muestra la informacion del archivo
                // regresa al principio del archivo
                //el seek establece posicion
                entrada.Seek(0, SeekOrigin.Begin);
                //cada que entre se inicie desde el origen

                txtMostrar.Text = "Las cuentas son: \r\n";
                // recorre el archivo hasta llegar a su fin con un while
                while (true)
                {
                    string[] camposEntrada; // almacena piezas de datos individuales
                    Registro registro; // almacena cada Registro a media que se lee el archivo
                    decimal saldo; // almacena el salfo de cada Registro

                    //obtiene el siguiente Registro disponble en el archivo
                    string registroEntrada = archivoReader.ReadLine();
                    //cuando esta al final del archivo sale del metodo
                    if (registroEntrada == null)
                    {
                        return;
                        //split es para separar por commas(,)
                        camposEntrada = registroEntrada.Split(',');//analiza la entrada

                        //crea el Registro a partir de entrada
                        //se convierten algunos campos a sus respectivos tipos
                        registro = new Registro(Convert.ToInt32(camposEntrada[0]), camposEntrada[1], camposEntrada[2], Convert.ToDecimal(camposEntrada[3]));
                        // almacena el ultimo campo del registro en saldo
                        saldo = registro.Saldo;
                        //determina si va a mostrar el saldo o no
                        if (DebeMostrar(saldo, tipoCuenta))
                        {
                            // muestra el registro
                            string salida = registro.Cuenta + "\t" +
                                registro.PrimerNombre + "\t" + registro.ApellidoPaterno + "\t";

                            //muestra el saldo con el formato monetario correcto
                            salida += String.Format("{0;F}", saldo) + "\r\n";

                            txtMostrar.Text += salida; // copia la salida a la pantalla
                        }
                    }
                }
            }
            //maneja la excepcion cuando no puede leerse el archivo
            catch (IOException)
            {
                MessageBox.Show("No se puede leer el archivo", "Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        //determina si se va a mostrar el registro dado
        private bool DebeMostrar(decimal saldo, string tipoCuenta)
        {
            if (saldo > 0) {
                //Muestra los saldos con credito

                if (tipoCuenta == "Saldos con crédito")
                {
                    return true;
                }
                else if (saldo < 0)
                {
                    //muestra los saldos con debito
                    if (tipoCuenta == "Saldos con débito")
                    {
                        return true;
                    }
                }
                else {
                    if (tipoCuenta == "Saldos en cero") {
                        return true;
                    }
                }
            }
            return false;


        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if(entrada != null)
            {
                try
                {
                    entrada.Close();
                    archivoReader.Close();
                }
                catch (IOException)
                {
                    MessageBox.Show("No se puede cerrar el archivo", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            Application.Exit();
        }
    }
}
